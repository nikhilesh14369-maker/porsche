require("dotenv").config();

const express = require("express");
const cors = require("cors");

const connectDB = require("./config/db");

const app = express();

connectDB();

app.use(cors());
app.use(express.json());
app.get("/", (req, res) => {

res.send("Luxury Car Booking API Running");

});

app.use("/api/auth", require("./routes/auth"));
app.use("/api/cars", require("./routes/cars"));
app.use("/api/bookings",require("./routes/booking"));
app.use("/api/subscriptions",require("./routes/subscription"));
app.use("/api/admin",require("./routes/admin"));
const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {

console.log(`Server running on ${PORT}`);

});