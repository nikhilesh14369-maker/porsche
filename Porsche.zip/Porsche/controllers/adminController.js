const User=require("../models/User");
const Car=require("../models/Car");
const Booking=require("../models/Booking");
const Subscription=require("../models/Subscription");

exports.dashboard=async(req,res)=>{

try{

const users=await User.countDocuments();

const cars=await Car.countDocuments();

const bookings=await Booking.countDocuments();

const subscriptions=await Subscription.countDocuments();

const revenue=await Booking.aggregate([
{
$group:{
_id:null,
total:{
$sum:"$totalPrice"
}
}
}
]);

res.json({

success:true,

stats:{
users,
cars,
bookings,
subscriptions,
revenue:
revenue.length>0
?revenue[0].total
:0
}

});

}catch(error){

res.status(500).json({

message:error.message

});

}

};

// Get all users

exports.getUsers=async(req,res)=>{

const users=await User.find().select("-password");

res.json(users);

};

// Get all bookings

exports.getBookings=async(req,res)=>{

const bookings=await Booking.find()

.populate("user")

.populate("car");

res.json(bookings);

};

// Get all subscriptions

exports.getSubscriptions=async(req,res)=>{

const subscriptions=await Subscription.find()

.populate("user");

res.json(subscriptions);

};