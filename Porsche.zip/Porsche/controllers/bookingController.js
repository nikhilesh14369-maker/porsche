const Booking = require("../models/Booking");
const Car = require("../models/Car");

// Create Booking
exports.createBooking = async (req,res)=>{

try{

const car=await Car.findById(req.body.car);

if(!car){

return res.status(404).json({
message:"Car not found"
});

}

const pickup=new Date(req.body.pickupDate);

const drop=new Date(req.body.returnDate);

const days=Math.ceil(
(drop-pickup)/(1000*60*60*24)
);

if(days<=0){

return res.status(400).json({
message:"Invalid booking dates"
});

}

const booking=await Booking.create({

user:req.user._id,

car:req.body.car,

pickupDate:req.body.pickupDate,

returnDate:req.body.returnDate,

pickupLocation:req.body.pickupLocation,

dropLocation:req.body.dropLocation,

totalDays:days,

totalPrice:days*car.pricePerDay

});

res.status(201).json({

success:true,

booking

});

}catch(error){

res.status(500).json({
message:error.message
});

}

};

// User Bookings
exports.getMyBookings=async(req,res)=>{

const bookings=await Booking.find({

user:req.user._id

}).populate("car");

res.json(bookings);

};

// Cancel Booking

exports.cancelBooking=async(req,res)=>{

const booking=await Booking.findById(req.params.id);

if(!booking){

return res.status(404).json({

message:"Booking not found"

});

}

booking.bookingStatus="Cancelled";

await booking.save();

res.json({

message:"Booking Cancelled"

});

};