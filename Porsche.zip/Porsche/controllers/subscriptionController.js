const Subscription=require("../models/Subscription");

exports.buySubscription=async(req,res)=>{

try{

const {plan}=req.body;

let amount=0;
let months=1;

switch(plan){

case "Basic":
amount=99;
months=1;
break;

case "Gold":
amount=249;
months=3;
break;

case "Platinum":
amount=799;
months=12;
break;

default:
return res.status(400).json({
message:"Invalid Plan"
});

}

const end=new Date();
end.setMonth(end.getMonth()+months);

const subscription=await Subscription.create({

user:req.user._id,

plan,

amount,

endDate:end,

paymentStatus:"Pending"

});

res.status(201).json({

success:true,

subscription

});

}catch(error){

res.status(500).json({

message:error.message

});

}

};

// Get Current Subscription

exports.getSubscription=async(req,res)=>{

try{

const subscription=await Subscription.findOne({

user:req.user._id,

active:true

});

res.json(subscription);

}catch(error){

res.status(500).json({

message:error.message

});

}

};