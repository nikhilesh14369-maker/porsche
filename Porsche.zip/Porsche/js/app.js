console.log("Luxury Car Booking Website Loaded");

const cards=document.querySelectorAll(".card");

cards.forEach(card=>{

card.addEventListener("mouseenter",()=>{

card.style.boxShadow="0 0 25px crimson";

});

card.addEventListener("mouseleave",()=>{

card.style.boxShadow="none";

});

});