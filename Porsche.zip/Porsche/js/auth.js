const togglePassword=document.getElementById("togglePassword");

if(togglePassword){

togglePassword.onclick=function(){

const password=document.getElementById("password");

password.type=password.type==="password"?"text":"password";

}

}

const toggleSignup=document.getElementById("toggleSignup");

if(toggleSignup){

toggleSignup.onclick=function(){

const password=document.getElementById("signupPassword");

password.type=password.type==="password"?"text":"password";

}

}

const loginForm=document.getElementById("loginForm");

if(loginForm){

loginForm.addEventListener("submit",(e)=>{

e.preventDefault();

alert("Login Successful");

window.location.href="dashboard.html";

});

}

const signupForm=document.getElementById("signupForm");

if(signupForm){

signupForm.addEventListener("submit",(e)=>{

e.preventDefault();

alert("Account Created Successfully");

window.location.href="login.html";

});

}