function calculatePrice(){

let pickup=new Date(document.getElementById("pickupDate").value);

let drop=new Date(document.getElementById("returnDate").value);

if(!pickup.getTime()||!drop.getTime()){

alert("Please select both dates");

return;

}

let days=(drop-pickup)/(1000*60*60*24);

if(days<=0){

alert("Return date must be after pickup date");

return;

}

let car=document.getElementById("carSelect").value;

let rate=0;

switch(car){

case "Porsche 911":
rate=300;
break;

case "Porsche Taycan":
rate=320;
break;

case "BMW M4":
rate=220;
break;

case "Audi R8":
rate=270;
break;

case "Mercedes AMG GT":
rate=280;
break;

case "Lamborghini Huracan":
rate=500;
break;

}

let total=days*rate;

document.getElementById("price").innerHTML=
"Estimated Price : $"+total;

}