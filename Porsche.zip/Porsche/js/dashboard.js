console.log("Dashboard Loaded");

const boxes=document.querySelectorAll(".box");

boxes.forEach(box=>{

box.addEventListener("mouseenter",()=>{

box.style.background="#2b2b2b";

});

box.addEventListener("mouseleave",()=>{

box.style.background="#222";

});

});