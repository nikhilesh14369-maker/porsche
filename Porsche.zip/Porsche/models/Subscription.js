const mongoose = require("mongoose");

const subscriptionSchema = new mongoose.Schema(
{
    user:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"User",
        required:true
    },

    plan:{
        type:String,
        enum:[
            "Basic",
            "Gold",
            "Platinum"
        ],
        required:true
    },

    amount:{
        type:Number,
        required:true
    },

    startDate:{
        type:Date,
        default:Date.now
    },

    endDate:{
        type:Date,
        required:true
    },

    paymentStatus:{
        type:String,
        enum:[
            "Pending",
            "Paid",
            "Failed"
        ],
        default:"Pending"
    },

    active:{
        type:Boolean,
        default:true
    }

},
{
    timestamps:true
});

module.exports = mongoose.model("Subscription",subscriptionSchema);