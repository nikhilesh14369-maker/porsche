const mongoose = require("mongoose");

const bookingSchema = new mongoose.Schema(
{
    user:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"User",
        required:true
    },

    car:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"Car",
        required:true
    },

    pickupDate:{
        type:Date,
        required:true
    },

    returnDate:{
        type:Date,
        required:true
    },

    pickupLocation:{
        type:String,
        required:true
    },

    dropLocation:{
        type:String,
        required:true
    },

    totalDays:{
        type:Number,
        required:true
    },

    totalPrice:{
        type:Number,
        required:true
    },

    bookingStatus:{
        type:String,
        enum:[
            "Pending",
            "Confirmed",
            "Cancelled",
            "Completed"
        ],
        default:"Pending"
    },

    paymentStatus:{
        type:String,
        enum:[
            "Pending",
            "Paid",
            "Refunded"
        ],
        default:"Pending"
    }

},
{
    timestamps:true
});

module.exports=mongoose.model("Booking",bookingSchema);