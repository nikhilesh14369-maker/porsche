const mongoose = require("mongoose");

const carSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
    },

    brand: {
      type: String,
      required: true,
      trim: true,
    },

    model: {
      type: String,
      required: true,
      trim: true,
    },

    year: {
      type: Number,
      required: true,
    },

    category: {
      type: String,
      enum: ["Sports", "SUV", "Sedan", "Luxury", "Electric"],
      default: "Luxury",
    },

    color: {
      type: String,
      required: true,
    },

    transmission: {
      type: String,
      enum: ["Automatic", "Manual"],
      default: "Automatic",
    },

    fuelType: {
      type: String,
      enum: ["Petrol", "Diesel", "Electric", "Hybrid"],
      default: "Petrol",
    },

    seats: {
      type: Number,
      default: 4,
    },

    pricePerDay: {
      type: Number,
      required: true,
    },

    description: {
      type: String,
      default: "",
    },

    images: [
      {
        type: String,
      },
    ],

    available: {
      type: Boolean,
      default: true,
    },

    rating: {
      type: Number,
      default: 5,
      min: 0,
      max: 5,
    },

    totalBookings: {
      type: Number,
      default: 0,
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("Car", carSchema);