const express=require("express");

const router=express.Router();

const auth=require("../middleware/authMiddleware");
const admin=require("../middleware/adminMiddleware");

const controller=require("../controllers/adminController");

router.get(
"/dashboard",
auth,
admin,
controller.dashboard
);

router.get(
"/users",
auth,
admin,
controller.getUsers
);

router.get(
"/bookings",
auth,
admin,
controller.getBookings
);

router.get(
"/subscriptions",
auth,
admin,
controller.getSubscriptions
);

module.exports=router;