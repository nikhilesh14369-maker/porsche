const express=require("express");

const router=express.Router();

const bookingController=require("../controllers/bookingController");

const auth=require("../middleware/authMiddleware");

// Create Booking

router.post(
"/",
auth,
bookingController.createBooking
);

// Get Logged-in User Bookings

router.get(
"/my-bookings",
auth,
bookingController.getMyBookings
);

// Cancel Booking

router.put(
"/cancel/:id",
auth,
bookingController.cancelBooking
);

module.exports=router;