const express = require("express");
const router = express.Router();

const carController = require("../controllers/carController");
const authMiddleware = require("../middleware/authMiddleware");

// Public Routes
router.get("/", carController.getCars);
router.get("/:id", carController.getCarById);

// Protected Routes (Admin)
router.post("/", authMiddleware, carController.createCar);
router.put("/:id", authMiddleware, carController.updateCar);
router.delete("/:id", authMiddleware, carController.deleteCar);

module.exports = router;