const express=require("express");

const router=express.Router();

const auth=require("../middleware/authMiddleware");

const controller=require("../controllers/subscriptionController");

// Purchase Subscription

router.post(

"/buy",

auth,

controller.buySubscription

);

// Get User Subscription

router.get(

"/",

auth,

controller.getSubscription

);

module.exports=router;